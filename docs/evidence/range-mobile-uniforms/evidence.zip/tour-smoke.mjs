import {chromium} from 'playwright';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {openEvaluationSong,renderEvaluationFrame} from '../tools/lib/visual-evaluation-browser.mjs';
const browser=await chromium.launch({args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try {
 const diagnostics={errors:[],warnings:[],loadedFiles:new Set()};
 const settings={width:550,height:310,seed:315,quality:3,view:null,biome:'CONIFER',presentation:{version:1,look:'natural',quality:'auto',palette:'range32',dither:.35,scaling:'fit'}};
 const mobileBrowser={newContext:async options=>{const context=await browser.newContext({...options,deviceScaleFactor:4,isMobile:true,hasTouch:true});await context.addInitScript(()=>Object.defineProperty(navigator,'maxTouchPoints',{get:()=>5}));return context;}};
 const loaded=await openEvaluationSong(mobileBrowser,{url:'http://127.0.0.1:8093/?rangeTour=tetons',audioPath:process.cwd()+'/.smoke/uniform-baseline/mobile-uniform-contrast/audio.wav',settings,diagnostics});
 const frames=[];
 for(const [look,timeMs] of [['natural',12000],['pixel',12500],['palette',13000]]){
  await loaded.page.evaluate(async look=>{const {resolvePresentation}=await import('/src/render/DisplayProfile.js');window.__SMW.renderer.setPresentation(resolvePresentation({...window.__SMW.displayPrefs,look}));},look);
  const frame=await renderEvaluationFrame(loaded.page,{timeMs,save:true,checkpoint:true,clips:[]},settings);
  assert.equal(frame.range.tourMode,'tetons');assert.equal(frame.range.viewId,'teton-range-tour');assert.equal(frame.range.active,true);assert.equal(frame.presentation.frame.presented,true);
  assert.equal(frame.presentation.effectiveLook,look);
  await fs.mkdir('.smoke/uniform-tour-final',{recursive:true});await fs.writeFile('.smoke/uniform-tour-final/'+look+'.png',Buffer.from(frame.pngData,'base64'));delete frame.pngData;delete frame.thumbnail;frames.push(frame);
 }
 const cancelled=diagnostics.errors.filter(e=>e==='request failed /src/assets/range/v2/tour/teton-range-tour.tour.json: net::ERR_ABORTED');
 const unexpected=diagnostics.errors.filter(e=>!cancelled.includes(e));
 const manifestStatus=await loaded.page.evaluate(async()=> (await fetch('/src/assets/range/v2/tour/teton-range-tour.tour.json')).status);
 assert.equal(manifestStatus,200);assert.deepEqual(unexpected,[]);
 assert.ok(frames.every(f=>f.range.residency.budget==='mobile'&&f.dpr===4));
 await fs.mkdir('.smoke/uniform-tour-final',{recursive:true});await fs.writeFile('.smoke/uniform-tour-final/report.json',JSON.stringify({settings,frames,errors:unexpected,cancelledGenerationRequests:cancelled,warnings:diagnostics.warnings,manifestStatus},null,2));
 console.log('Tour Natural/Pixel/Palette frames passed');
 await loaded.context.close();
}finally{await browser.close();}
