// Normal audio/RAF playback measurement; no export or fixed-step helpers.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { chromium } from '../Midio-5/node_modules/playwright/index.mjs';
import { seedBrowserConstruction } from '../baseline-source/tools/lib/landscape-browser.mjs';
const args={};for(let i=2;i<process.argv.length;i+=2)args[process.argv[i].slice(2)]=process.argv[i+1];
const out=path.dirname(fileURLToPath(import.meta.url)), source=path.resolve(args['source-root']||path.join(out,'../baseline-source'));
const url=args.url||'http://127.0.0.1:8195',tag=args.tag||'prepared-probe',fixture=path.join(out,'synthetic-120s.wav');
const reportPath=path.join(out,`${tag}-live-performance.json`);
if(await fs.access(reportPath).then(()=>true,()=>false))throw Error('Evidence already exists; choose a fresh --tag: '+reportPath);
const hash=b=>createHash('sha256').update(b).digest('hex');
const report={classification:'Normal audio-driven headed playback, measured draw intervals; controlled cases are explicitly labelled',startedAtUTC:new Date().toISOString(),harnessSha256:hash(await fs.readFile(fileURLToPath(import.meta.url))),sourceRoot:source,sourceCommit:args.sha||'341a976',url,fixture:{name:path.basename(fixture),sha256:hash(await fs.readFile(fixture))},settings:{viewport:{width:1280,height:780},dpr:1,stagePreset:'auto',fpsCap:60,songSeed:2917029651,constructionSeed:315,seedControl:{receiver:'seedInput',value:'0xADDE5713',timing:'before deferred app modules'},rangeExperience:'revelation',steadyView:'teton-jackson-lake',measureSeconds:15},runs:[]};
const launchArgs=['--use-angle=d3d11','--enable-gpu','--ignore-gpu-blocklist','--enable-gpu-rasterization'];
const browser=await chromium.launch({headless:false,executablePath:'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',args:launchArgs});
report.browser={version:browser.version(),headless:false,launchArgs,executable:'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'};
let intentionalBrowserClose=false;report.browserLifecycle=[];browser.on('disconnected',()=>report.browserLifecycle.push({event:'disconnected',intentional:intentionalBrowserClose,atUTC:new Date().toISOString()}));
try{const cdp=await browser.newBrowserCDPSession();report.systemGpu=(await cdp.send('SystemInfo.getInfo')).gpu;}catch(e){report.systemGpuError=String(e);}
const distribution=xs=>{if(!xs.length)return null;const x=xs.slice().sort((a,b)=>a-b),q=p=>x[Math.ceil(p*x.length)-1];return{n:x.length,median:q(.5),p95:q(.95),p99:q(.99),max:x.at(-1),above25ms:xs.filter(v=>v>25).length/x.length,above50ms:xs.filter(v=>v>50).length/x.length,above100ms:xs.filter(v=>v>100).length/x.length};};
async function run(index,natural=false,{controlled=false,queries=true,durationSeconds=15}={}){
 const context=await browser.newContext({viewport:report.settings.viewport,deviceScaleFactor:1,serviceWorkers:'block'});
 await context.addInitScript(seedBrowserConstruction,315);
 await context.addInitScript(()=>{const install=()=>{if(!document.body)return false;const input=document.getElementById('seedInput')||document.createElement('input');input.hidden=true;input.id='seedInput';input.value='0xADDE5713';if(!input.parentNode)document.body.prepend(input);return true;};if(!install()){const observer=new MutationObserver(()=>{if(install())observer.disconnect();});observer.observe(document,{childList:true,subtree:true});}});
 const page=await context.newPage(),row={index,case:controlled?'controlled-distinct-view-travel':natural?'natural-travel':queries?'pinned-steady':'pinned-steady-no-gpu-query-control',gpuQueriesEnabled:queries,durationSeconds,startedAtUTC:new Date().toISOString(),interventions:[],errors:[],sourceReadErrors:[],sourceHashes:{}};
 let intentionalContextClose=false;row.lifecycle=[];page.on('close',()=>row.lifecycle.push({event:'page-close',intentional:intentionalContextClose,atUTC:new Date().toISOString()}));page.on('crash',()=>row.lifecycle.push({event:'page-crash',atUTC:new Date().toISOString()}));
 const pending=[];
 const watchResponse=response=>{const file=new URL(response.url()).pathname.replace(/^\/+/, '');if(!file.startsWith('src/')||!response.ok())return;pending.push((async()=>{let body;try{body=await response.body();}catch(e){row.sourceReadErrors.push({file,url:response.url(),error:String(e)});return;}try{const h=hash(body);if(h!==hash(await fs.readFile(path.join(source,file))))throw Error('source mismatch '+file);row.sourceHashes[file]=h;}catch(e){row.errors.push(String(e));}})());};page.on('response',watchResponse);
 page.on('pageerror',e=>row.errors.push(e.message));page.on('console',m=>{if(/Shader Error|program not valid|\[draw\]|\[sim.step\]/.test(m.text()))row.errors.push(m.text());});
 await context.route('**/soundfonts/',route=>route.fulfill({json:[]}));await context.route(/^https:\/\//,route=>route.abort());
 try{
  const entry=new URL(url);entry.searchParams.set('rangeRenderer','v2');entry.searchParams.set('rangeExperience','revelation');entry.searchParams.set('seed','2917029651');if(!natural&&!controlled)entry.searchParams.set('rangeView','teton-jackson-lake');else entry.searchParams.delete('rangeView');
  await page.goto(entry.href);await page.bringToFront();
  await page.locator('#titleSettings').evaluate(n=>{n.open=true;});
  if(await page.locator('#lyricGroundingBtn').getAttribute('aria-pressed')==='true')await page.locator('#lyricGroundingBtn').click();
  await page.locator('#stageRes').selectOption('auto');await page.locator('#stageFps').selectOption('60');
  await page.locator('#fileInput').setInputFiles(fixture);
  const picker=await Promise.race([page.locator('#worldSelect[open]').waitFor({timeout:120000}).then(()=>true),page.waitForFunction(()=>!!window.__SMW?.sim,null,{timeout:120000}).then(()=>false)]);
  if(picker){const card=page.locator('.worldCard[data-base-world-id="alpine"]');await card.first().locator('.worldCardPlayBtn').click();}
  await page.waitForFunction(()=>{const s=window.__SMW;return s?.rangeState?.active&&!s.sim.analysisOpening&&s.audioEngine.ctx.state==='running'&&!s.exportReady;},null,{timeout:120000});
  if(controlled){
   row.controlledSetup=await page.evaluate(()=>{
    const s=window.__SMW,m=s.sim.biomes,p=m.rangePresentation;
    if(p.forced)throw Error('controlled travel must have no forced view');
    const a=p.catalog.views.find(v=>v.id==='teton-jackson-lake'&&v.status==='approved'),b=p.catalog.views.find(v=>v.id==='muncho-lake-south'&&v.status==='approved');
    if(!a||!b||a.id===b.id)throw Error('approved controlled travel pair unavailable');
    const originalSections=m.sections,originalAssignments=p.sceneByBiome;
    const assignments=new Map(originalAssignments);assignments.set(a.biome,{view:a,fallbackReason:null});assignments.set(b.biome,{view:b,fallbackReason:null});p.sceneByBiome=assignments;
    const schedule=[{startMs:0,endMs:20000,profile:a.biome},{startMs:20000,endMs:32000,profile:b.biome},{startMs:32000,endMs:44000,profile:a.biome},{startMs:44000,endMs:s.durationMs,profile:b.biome}];
    m.sections=schedule.map((x,i)=>({...originalSections[0],...x,barMs:2000,transition:'fade',chapterId:'external-controlled:'+i,provenance:'external-controlled-timing',heightMul:1,snowLine01:1}));
    window.__CONTROLLED_TIMING={cleanup(){m.sections=originalSections;p.sceneByBiome=originalAssignments;return m.sections===originalSections&&p.sceneByBiome===originalAssignments;}};
    p._prepare(a);p._prepare(b);
    return {classification:'External controlled section schedule with production A/B travel compositor, not naturally selected song travel',pair:[{id:a.id,biome:a.biome},{id:b.id,biome:b.biome}],schedule,warmPreparationRequested:true,changedFields:['sim.biomes.sections','RangePresentation.sceneByBiome'],originalProfiles:originalSections.map(x=>x.profile)};
   });
   await page.waitForFunction(()=>{const p=window.__SMW.sim.biomes.rangePresentation;return p.scene.isReady('teton-jackson-lake')&&p.scene.isReady('muncho-lake-south');},null,{timeout:60000});
   const delayedSchedule=await page.evaluate(()=>{const s=window.__SMW,m=s.sim.biomes,p=m.rangePresentation,preparedAtAudioMs=s.audioEngine.nowMs,first=Math.ceil((preparedAtAudioMs+8000)/1000)*1000;const a=p.catalog.views.find(v=>v.id==='teton-jackson-lake'),b=p.catalog.views.find(v=>v.id==='muncho-lake-south');const schedule=[{startMs:0,endMs:first,profile:a.biome},{startMs:first,endMs:first+12000,profile:b.biome},{startMs:first+12000,endMs:first+24000,profile:a.biome},{startMs:first+24000,endMs:s.durationMs,profile:b.biome}];m.sections=schedule.map((x,i)=>({...m.sections[0],...x,chapterId:'external-controlled-delayed:'+i}));return {schedule,preparedAtAudioMs,measureFromMs:first,reason:'Both approved views prepared before choosing a future transition boundary; adds at least 8 seconds for stable sampler warmup'};});
   Object.assign(row.controlledSetup,delayedSchedule);
   row.interventions.push('External controlled chapter-section schedule and two approved scene assignments; both views prepared before window; audio clock and production travel rendering unchanged.');
  }
  row.preflight=await page.evaluate(()=>{
   const s=window.__SMW,p=s.sim.biomes.rangePresentation,gl=p.scene.renderer.getContext(),d=gl.getExtension('WEBGL_debug_renderer_info');
   const sections=s.sim.biomes.sections.map(a=>({startMs:a.startMs,endMs:a.endMs,profile:typeof a.profile==='string'?a.profile:a.profile?.name,biome:a.biome,name:a.name}));
   return {gl: d?gl.getParameter(d.UNMASKED_RENDERER_WEBGL):null,timerQuery:!!gl.getExtension('EXT_disjoint_timer_query_webgl2'),exportReady:s.exportReady,audioState:s.audioEngine.ctx.state,audioNowMs:s.audioEngine.nowMs,analysisOpening:s.sim.analysisOpening,analysis: {binMs:s.analysis?.binMs,durationMs:s.analysis?.durationMs,bins:s.analysis?.bins?.length},terrainAllLoaded:s.sim.biomes.songTerrain?.allLoaded,seed:s.songSeed,seedReceiver:document.getElementById('seedInput')?.value,sections,cast:(s.sim.biomes.songTerrain?.biomes||[]).map(b=>({biome:b,view:s.sim.biomes.songTerrain.sceneByBiome.get(b)?.view?.id})),prefs:{stage:document.querySelector('#stageRes').value,fps:document.querySelector('#stageFps').value,storedStage:localStorage.getItem('smw:stageRes'),storedFps:localStorage.getItem('smw:stageFps')},visibility:document.visibilityState,focused:document.hasFocus(),fullscreen:!!document.fullscreenElement,viewport:{innerWidth,innerHeight,outerWidth,outerHeight,dpr:devicePixelRatio,visualViewport:{width:visualViewport.width,height:visualViewport.height,scale:visualViewport.scale},screen:{width:screen.width,height:screen.height,availWidth:screen.availWidth,availHeight:screen.availHeight}},stageRect:document.querySelector('#stage').getBoundingClientRect().toJSON(),range:s.rangeState,reducedMotion:s.sim.reducedMotion,reducedFlash:s.sim.reducedFlash};
  });
  if(!/NVIDIA GeForce RTX 3060.*D3D11/.test(row.preflight.gl||''))throw Error('Expected RTX3060 D3D11; got '+row.preflight.gl);
  if(row.preflight.seed!==2917029651||!row.preflight.timerQuery)throw Error('seed/GPU timer preflight failed');
  console.log(`run ${index} ${row.case}: hardware ready, audio ${Math.round(row.preflight.audioNowMs)}ms`);
  await page.evaluate(({gpuQueriesEnabled})=>{
   let s=window.__SMW,renderer=s.renderer,gl=s.sim.biomes.rangePresentation.scene.renderer.getContext(),ext=gl.getExtension('EXT_disjoint_timer_query_webgl2'),original=renderer.draw;
   const data={gpuQueriesEnabled,rows:[],raf:[],gpu:[],longTasks:[],events:[],warmupRows:[],pending:[],maxPending:0,skipped:0,invalid:0,drawCount:0,startWall:null,endWall:null,queryId:0,active:false,lastRebindWall:performance.now(),rebinds:[],rendererChangedDuringWindow:false};
   let handle=null,observer=null,recording=false,lastIdentity=s,lastDraw=null,lastState=null;
   const poll=()=>{for(let i=data.pending.length-1;i>=0;i--){const q=data.pending[i];if(gl.isContextLost()||gl.getParameter(ext.GPU_DISJOINT_EXT)){gl.deleteQuery(q.query);data.invalid++;data.pending.splice(i,1);continue;}if(!gl.getQueryParameter(q.query,gl.QUERY_RESULT_AVAILABLE))continue;data.gpu.push({id:q.id,drawId:q.drawId,wall:q.wall,ms:gl.getQueryParameter(q.query,gl.QUERY_RESULT)/1e6,measured:q.measured});gl.deleteQuery(q.query);data.pending.splice(i,1);}};
   const raf=t=>{const current=window.__SMW;if(current!==s||current?.renderer!==renderer){if(recording){data.rendererChangedDuringWindow=true;}else if(current?.sim?.biomes?.rangePresentation?.scene?.renderer){renderer.draw=original;for(const q of data.pending)gl.deleteQuery(q.query);data.invalid+=data.pending.length;data.pending=[];s=current;renderer=s.renderer;original=renderer.draw;gl=s.sim.biomes.rangePresentation.scene.renderer.getContext();ext=gl.getExtension('EXT_disjoint_timer_query_webgl2');lastIdentity=s;lastDraw=null;data.lastRebindWall=performance.now();data.rebinds.push({wall:data.lastRebindWall,audioMs:s.audioEngine.nowMs,analysisOpening:s.sim.analysisOpening});renderer.draw=wrapped;}}if(recording)data.raf.push(t);poll();handle=requestAnimationFrame(raf);};handle=requestAnimationFrame(raf);
   try{observer=new PerformanceObserver(entries=>{if(recording)for(const x of entries.getEntries())data.longTasks.push({start:x.startTime,duration:x.duration});});observer.observe({type:'longtask',buffered:false});}catch(e){data.longTaskUnsupported=String(e);}
   const wrapped=function(...xs){
    const smw=window.__SMW,now=performance.now();data.drawCount++;let query=null,id=null;
    if(gpuQueriesEnabled&&data.drawCount%10===0&&data.pending.length<8&&!gl.isContextLost()){id=++data.queryId;query=gl.createQuery();gl.beginQuery(ext.TIME_ELAPSED_EXT,query);}else if(gpuQueriesEnabled&&data.drawCount%10===0)data.skipped++;
    try{return original.apply(this,xs);}finally{
     if(query&&!gl.isContextLost()){gl.endQuery(ext.TIME_ELAPSED_EXT);data.pending.push({query,id,drawId:data.drawCount,wall:now,measured:recording});data.maxPending=Math.max(data.maxPending,data.pending.length);}
     const b=smw.sim.biomes.currentBlend||{},rp=smw.sim.biomes.rangePresentation,c=document.querySelector('#stage'),scene=rp.scene;
     const state={quality:smw.perfLevel,w:c.width,h:c.height,sw:scene.size.width,sh:scene.size.height,view:rp.viewId,incoming:rp.incomingViewId,active:rp.active,reason:rp.reason,arrival:rp.arrival,incomingFade:rp.incomingFade,seamP:rp.seamP,sideB:!!scene.sideTargets.B,from:b.from,to:b.to,travel:!!b.travel,travelP:b.travelP};
     const sig=JSON.stringify(state);
     if(recording&&sig!==lastState){data.events.push({wall:now,audioMs:smw.audioEngine.nowMs,...state});lastState=sig;}
     const record={wall:now,drawId:data.drawCount,dtMs:lastDraw==null?null:now-lastDraw,drawMs:performance.now()-now,audioMs:smw.audioEngine.nowMs,simMs:smw.sim.timeMs,heardMs:smw.sim.heardTimeMs,queryId:id,contextEpoch:scene.contextEpoch,visible:!document.hidden,focused:document.hasFocus(),audioRunning:smw.audioEngine.ctx.state==='running',sameRenderer:smw.renderer===renderer&&smw===lastIdentity,...state};
     if(recording)data.rows.push(record);else if(data.warmupRows.length<600)data.warmupRows.push(record);lastDraw=now;
    }
   };
   renderer.draw=wrapped;
   window.__LIVE_PERF={data,ready(){return window.__SMW===s&&s.renderer===renderer&&s.sim.biomes.rangePresentation.scene.renderer.getContext()===gl&&!s.sim.analysisOpening&&performance.now()-data.lastRebindWall>=5000;},start(){if(!this.ready())throw Error('sampler identity/full-analysis warmup not stable');recording=true;lastDraw=null;data.startWall=performance.now();data.startAudioMs=s.audioEngine.nowMs;data.startRange=s.rangeState;data.startContextEpoch=s.sim.biomes.rangePresentation.scene.contextEpoch;},stop(){recording=false;data.endWall=performance.now();data.endAudioMs=s.audioEngine.nowMs;data.endRange=s.rangeState;data.endContextEpoch=s.sim.biomes.rangePresentation.scene.contextEpoch;},cleanup(){if(data.cleaned)return;renderer.draw=original;cancelAnimationFrame(handle);observer?.disconnect();poll();for(const q of data.pending)gl.deleteQuery(q.query);data.pendingCountAtCleanup=data.pending.length;data.pending=[];data.restored=renderer.draw===original;data.cleaned=true;}};
  },{gpuQueriesEnabled:queries});
  let fromMs=controlled?row.controlledSetup.measureFromMs:20000;
  if(natural&&!controlled){const first=row.preflight.sections.find((s,i)=>i>0&&s.profile!==row.preflight.sections[i-1].profile&&s.startMs>15000&&s.startMs<80000);if(first)fromMs=Math.max(15000,first.startMs-4000);row.naturalTargetStartMs=fromMs;row.naturalTargetBoundary=first||null;}
  await page.waitForFunction(t=>window.__SMW.audioEngine.nowMs>=t&&window.__LIVE_PERF.ready()&&(window.__LIVE_PERF.data.gpuQueriesEnabled?window.__LIVE_PERF.data.gpu.length>=3:window.__LIVE_PERF.data.warmupRows.length>=120),fromMs,{timeout:120000});
  if(controlled&&await page.evaluate(()=>window.__SMW.audioEngine.nowMs)>fromMs+3000)throw Error('controlled preparation missed first scheduled transition; do not claim matched travel window');
  await page.evaluate(()=>window.__LIVE_PERF.start());await page.waitForTimeout(durationSeconds*1000);await page.evaluate(()=>window.__LIVE_PERF.stop());await page.waitForTimeout(250);
  row.instrumentation=await page.evaluate(()=>{window.__LIVE_PERF.cleanup();const d=window.__LIVE_PERF.data;return {...d,pending:undefined};});
  const rows=row.instrumentation.rows;
  const steady=x=>x.active&&!x.incoming&&!x.sideB&&x.arrival>=.99;
  const travel=x=>x.active&&x.incoming&&x.incoming!==x.view&&x.sideB&&x.seamP>.1&&x.seamP<.9;
  const qualify=(x,prev)=>x.dtMs!=null&&prev&&x.visible&&prev.visible&&x.audioRunning&&prev.audioRunning&&x.sameRenderer&&prev.sameRenderer;
  const all=rows.filter((x,i)=>qualify(x,rows[i-1])),settled=rows.filter((x,i)=>qualify(x,rows[i-1])&&steady(x)&&steady(rows[i-1])),travelling=rows.filter((x,i)=>qualify(x,rows[i-1])&&travel(x)&&travel(rows[i-1]));
  const gpuFor=xs=>{const ids=new Set(xs.map(x=>x.drawId));return row.instrumentation.gpu.filter(g=>g.measured&&ids.has(g.drawId)).map(g=>g.ms);};
  const regimes={};for(const x of all){const key=`q${x.quality}:${x.w}x${x.h}:${x.sw}x${x.sh}`;(regimes[key]||=[]).push(x.dtMs);}
  row.summary={wallMs:row.instrumentation.endWall-row.instrumentation.startWall,audioDeltaMs:row.instrumentation.endAudioMs-row.instrumentation.startAudioMs,draws:rows.length,drawsPerSecond:rows.length/(row.instrumentation.endWall-row.instrumentation.startWall)*1000,allDrawIntervalsMs:distribution(all.map(x=>x.dtMs)),steadyIntervalsMs:distribution(settled.map(x=>x.dtMs)),travelIntervalsMs:distribution(travelling.map(x=>x.dtMs)),jsDrawWallMs:distribution(all.map(x=>x.drawMs)),steadyGpuRegionMs:distribution(gpuFor(settled)),travelGpuRegionMs:distribution(gpuFor(travelling)),rafIntervalsMs:distribution(row.instrumentation.raf.slice(1).map((t,i)=>t-row.instrumentation.raf[i])),regimes:Object.fromEntries(Object.entries(regimes).map(([k,v])=>[k,distribution(v)])),invalidVisibilityRows:rows.filter(x=>!x.visible).length,unfocusedRows:rows.filter(x=>!x.focused).length,rendererChangedRows:rows.filter(x=>!x.sameRenderer).length,legacyRows:rows.filter(x=>!x.active).length,travelObserved:travelling.length>0,longTasks:row.instrumentation.longTasks.length,cleanupRestored:row.instrumentation.restored};
  if(all.length<300||row.summary.invalidVisibilityRows||row.summary.unfocusedRows||row.summary.rendererChangedRows||row.instrumentation.rendererChangedDuringWindow||row.instrumentation.startContextEpoch!==row.instrumentation.endContextEpoch)row.errors.push('Live timing window insufficient or contaminated; inspect raw rows before accepting performance evidence');
  if(controlled){row.summary.controlledTravelVerified=travelling.length>=120&&new Set(travelling.map(x=>`${x.view}->${x.incoming}`)).size>=2;row.summary.controlledTravelPairs=[...new Set(travelling.map(x=>`${x.view}->${x.incoming}`))];row.summary.controlledTravelIntervals=travelling.length;if(!row.summary.controlledTravelVerified)row.errors.push('Controlled actual travel evidence insufficient: require >=120 intervals and both A->B/B->A distinct-view seams');}
  page.off('response',watchResponse);await Promise.all(pending);row.unverifiedSourceReadErrors=row.sourceReadErrors.filter(e=>!row.sourceHashes[e.file]);if(row.unverifiedSourceReadErrors.length)row.errors.push('Some unique served files have no readable hash; source identity unverified');row.loadedSourceDigest=hash(Object.entries(row.sourceHashes).sort(([a],[b])=>a.localeCompare(b)).map(([f,h])=>`${f} ${h}\n`).join(''));
  console.log(`run ${index} ${row.case}: ${JSON.stringify(row.summary)}`);
 }catch(e){row.error=String(e.stack);console.error(row.error);}
 finally{page.off('response',watchResponse);try{row.cleanup=await page.evaluate(async()=>{window.__LIVE_PERF?.cleanup();const controlledScheduleRestored=window.__CONTROLLED_TIMING?.cleanup()??null;const s=window.__SMW;if(s?.audioEngine?.ctx)await s.audioEngine.ctx.suspend();return{instrumentationRestored:window.__LIVE_PERF?.data.restored??null,controlledScheduleRestored,audioState:s?.audioEngine?.ctx?.state??null};});}catch(e){row.cleanupError=String(e);}intentionalContextClose=true;await context.close();row.endedAtUTC=new Date().toISOString();report.runs.push(row);await fs.writeFile(reportPath,JSON.stringify(report,null,2));}
}
try{for(let i=1;i<=Number(args['steady-runs']??3);i++)await run(i);if(args.travel!=='0')await run(4,true);if(args['controlled-travel']==='1')await run(5,false,{controlled:true,durationSeconds:24});if(args['query-control']==='1')await run(6,false,{queries:false,durationSeconds:10});}finally{intentionalBrowserClose=true;await browser.close();report.browserClosed=true;report.endedAtUTC=new Date().toISOString();if(report.runs.some(r=>r.error||r.errors.length||r.cleanupError))process.exitCode=1;await fs.writeFile(reportPath,JSON.stringify(report,null,2));}
